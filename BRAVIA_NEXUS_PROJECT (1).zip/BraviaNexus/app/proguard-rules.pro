# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-dontwarn kotlin.reflect.**
